Game.LoadMod('https://lbr88-labs.github.io/CookieBot/cookieAutoPlayBeta.js');
